package com.account.service.impl;

import com.account.bean.Account;
import com.account.bean.Client;
import com.account.service.AccountService;

public class AccountServiceImpl implements AccountService {

	@Override
	public Account findByName(String name) {
		Account account = null;
		if(name.equals("pierre-jean")) {
			account = new Account();
			account.setBalance(100.0);
			account.setId(1);
			
			Client client = new Client();
			client.setId(1);
			client.setName("pierre-jean");
			account.setClient(client);
		}
		return account;
	}

	@Override
	public void withdraws(Account account, double d) {
		double newBalance = account.getBalance() - d;
		account.setBalance(newBalance);
	}

}
