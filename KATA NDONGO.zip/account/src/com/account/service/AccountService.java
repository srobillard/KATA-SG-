package com.account.service;

import com.account.bean.Account;

public interface AccountService {

	public Account findByName(String name);

	public void withdraws(Account account, double d);

}
