package com.account.step;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.account.bean.Account;
import com.account.service.AccountService;
import com.account.service.impl.AccountServiceImpl;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountSteps {

	private static Account account;
	private AccountService service;

	public static synchronized Account getInstance() {
		if(account == null) {
			account = new Account();
		}
		return account;
	}

	@Test
	public void test1givenAnExistingClientNamedpierrejeanWith100EURInHisAccount() {
		this.givenAnExistingClientNamed("pierre-jean", 100.0);
	}

	@Test
	public void test2whenHeWithdraws100EURFromHisAccount() {
		this.whenHeWithdrawsFromAccount(10.0);
	}

	@Test
	public void test3thenTheNewBalanceIs90EUR() {
		account = getInstance();
		assertThat(account.getBalance(), equalTo(90.0));
	}

	private void whenHeWithdrawsFromAccount(double withdraws) {
		account = getInstance();
		service = new AccountServiceImpl();
		service.withdraws(account, withdraws);
	}

	private void givenAnExistingClientNamed(String name, double balance) {
		account = getInstance();
		service = new AccountServiceImpl();
		account = service.findByName(name);
		assertThat(account.getBalance(), equalTo(balance));
	}
}